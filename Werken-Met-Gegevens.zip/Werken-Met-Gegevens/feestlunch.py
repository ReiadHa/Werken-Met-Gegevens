criossantjes = 0.39 
hoeveelheidcriossantjes = 17
stokbroden = 2.78
hoeveelheidstobroden = 2
korting = 0.5
hoeveelheidkorting =3


print(' de kosten van de feestluch zijn ' + str((criossantjes*hoeveelheidcriossantjes)+(stokbroden*hoeveelheidstobroden)-(korting*hoeveelheidkorting)))

