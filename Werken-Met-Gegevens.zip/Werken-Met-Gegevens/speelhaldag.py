personen = 3
entreekosten = 7.45
VijfMinVR = 0.37/5
Hoeveelheidmin = 45


print('de kosten van speelhaldag zijn ' + str((personen*entreekosten)+(VijfMinVR*Hoeveelheidmin)))